package com.miracle.miraclelaundry.mqtt

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken
import org.eclipse.paho.client.mqttv3.MqttCallback
import org.eclipse.paho.client.mqttv3.MqttClient
import org.eclipse.paho.client.mqttv3.MqttConnectOptions
import org.eclipse.paho.client.mqttv3.MqttMessage
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence
import org.json.JSONObject

/**
 * Gerenciador MQTT para o Miracle Laundry.
 *
 * – Conecta no broker MQTT
 * – Assina os tópicos de status das máquinas
 * – Envia comandos de START/STOP para as máquinas
 *
 * Padrão de tópicos (sugestão):
 *
 *  Status:
 *      miracle/machines/{machineId}/status
 *      payload JSON: { "status": "USED", "remaining": 15 }
 *
 *  Comando:
 *      miracle/machines/{machineId}/command
 *      payload JSON: { "command": "START" }
 */
class MqttManager(
    private val serverUri: String,   // Ex: "tcp://192.168.0.10:1883"
    private val clientId: String,    // Ex: "miracle-app-123"
    private val onMachineStatusUpdate: (machineId: String, status: String, remainingMinutes: Int) -> Unit
) {

    private val persistence = MemoryPersistence()
    private val client: MqttClient = MqttClient(serverUri, clientId, persistence)

    // Prefixos de tópicos
    private val statusTopicFilter = "miracle/machines/+/status"

    fun connectAndSubscribe() {
        if (client.isConnected) return

        val options = MqttConnectOptions().apply {
            isAutomaticReconnect = true
            isCleanSession = true
            connectionTimeout = 10
        }

        client.setCallback(object : MqttCallback {
            override fun connectionLost(cause: Throwable?) {
                cause?.printStackTrace()
            }

            override fun messageArrived(topic: String, message: MqttMessage) {
                // Ex: miracle/machines/washer_1/status
                val parts = topic.split("/")
                if (parts.size >= 4 && parts[0] == "miracle" && parts[1] == "machines") {
                    val machineId = parts[2]

                    try {
                        val json = JSONObject(message.toString())
                        val status = json.optString("status", "AVAILABLE")
                        val remaining = json.optInt("remaining", 0)

                        onMachineStatusUpdate(machineId, status, remaining)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }

            override fun deliveryComplete(token: IMqttDeliveryToken?) {
                // Não precisamos fazer nada aqui por enquanto
            }
        })

        // IMPORTANTE: conectar em uma thread separada para não travar a UI
        Thread {
            try {
                client.connect(options)
                client.subscribe(statusTopicFilter, 1)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }

    fun disconnect() {
        try {
            if (client.isConnected) {
                client.disconnect()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Envia comando para iniciar a máquina.
     * machineId: ex "washer_1", "dryer_2" etc.
     */
    fun sendStartCommand(machineId: String) {
        sendCommand(machineId, "START")
    }

    /**
     * Envia comando para parar a máquina (se precisar no futuro).
     */
    fun sendStopCommand(machineId: String) {
        sendCommand(machineId, "STOP")
    }

    private fun sendCommand(machineId: String, command: String) {
        if (!client.isConnected) return

        val topic = "miracle/machines/$machineId/command"
        val payloadJson = JSONObject().apply {
            put("command", command)
        }

        val message = MqttMessage(payloadJson.toString().toByteArray()).apply {
            qos = 1
        }

        try {
            client.publish(topic, message)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}