package com.miracle.miraclelaundry.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.miracle.miraclelaundry.navigation.Routes
import java.text.SimpleDateFormat
import java.util.*
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import com.miracle.miraclelaundry.R

// ------------------- MODELO -------------------
data class HistoryEntry(
    val emoji: String,
    val title: String,
    val unit: String,
    val date: String,
    val status: String,
    val statusColor: Color
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(navController: NavController) {

    val primary = Color(0xFF8B1538)
    val primaryDark = Color(0xFF6F0F2C)
    val headerBackground = Brush.verticalGradient(listOf(primaryDark, primary))

    var showDatePicker by remember { mutableStateOf(false) }
    val datePickerState = rememberDatePickerState()
    var selectedDate by remember { mutableStateOf<String?>(null) }

    var selectedEntry by remember { mutableStateOf<HistoryEntry?>(null) }

    val historico = listOf(
        HistoryEntry("🧺", "Lavagem Completa", "Unidade Centro • Máquina 03", "25/11/2025", "Concluído", Color(0xFF34D399)),
        HistoryEntry("💨", "Secagem Rápida",   "Unidade Norte • Secadora 01", "25/11/2025", "Concluído", Color(0xFF60A5FA)),
        HistoryEntry("🧺", "Lavagem Expressa","Unidade Centro • Máquina 02", "23/11/2025", "Concluído", Color(0xFF34D399))
    )

    val filteredList = historico.filter {
        selectedDate == null || it.date == selectedDate
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F5F5))
    ) {

        // ============================================================
        //   🔥 HEADER IGUAL AO DA HOME — SÓ MUDA O NOME DA TELA 🔥
        // ============================================================
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(headerBackground)
                .padding(top = 64.dp, bottom = 22.dp)
        ) {

            Column(Modifier.padding(horizontal = 18.dp)) {

                Row(verticalAlignment = Alignment.CenterVertically) {

                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .shadow(8.dp, RoundedCornerShape(16.dp))
                            .background(Color.White, RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.miracle_logo),
                            contentDescription = "Logo Miracle Laundry",
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(16.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }

                    Spacer(Modifier.width(14.dp))

                    Column {
                        Text(
                            "Miracle Laundry",
                            fontSize = 26.sp,
                            color = Color.White
                        )
                        Text(
                            "Histórico de serviços",
                            fontSize = 15.sp,
                            color = Color(0xFFFFF8F8)
                        )
                    }
                }

                Spacer(Modifier.height(22.dp))

                // === Menu superior padrão ===
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    TopMenuItem("🏠", "Início", false) { navController.navigate(Routes.HOME) }
                    TopMenuItem("🧺", "Máquinas", false) { navController.navigate(Routes.MACHINES) }
                    TopMenuItem("📜", "Histórico", true) { }
                    TopMenuItem("💳", "Carteira", false) { navController.navigate(Routes.WALLET) }
                    TopMenuItem("👤", "Perfil", false) { navController.navigate(Routes.PROFILE) }
                }
            }
        }

        // ================= FILTRO DATA =================
        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Button(
                onClick = { showDatePicker = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(primary)
            ) {
                Text(
                    selectedDate ?: "Filtrar por data",
                    fontSize = 15.sp
                )
            }
        }

        // ================= LISTA =================
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {

            filteredList.forEach { item ->
                HistoryEntryCard(item) { selectedEntry = item }
                Spacer(Modifier.height(14.dp))
            }

            Spacer(Modifier.height(40.dp))
        }
    }

    // ================= DATE PICKER =================
    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val millis = datePickerState.selectedDateMillis
                        if (millis != null) {
                            selectedDate = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                                .format(Date(millis))
                        }
                        showDatePicker = false
                    }
                ) { Text("Filtrar") }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text("Cancelar")
                }
            }
        ) {
            DatePicker(
                state = datePickerState,
                modifier = Modifier.width(320.dp)
            )
        }
    }

    // ================= MODAL =================
    if (selectedEntry != null) {
        ReceiptModal(entry = selectedEntry!!, onClose = { selectedEntry = null })
    }
}

// ================================================================
//                  CARDS E COMPONENTES MANTIDOS IGUAIS
// ================================================================
@Composable
fun HistoryEntryCard(item: HistoryEntry, onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .shadow(8.dp, RoundedCornerShape(26.dp))
            .background(Color.White, RoundedCornerShape(26.dp))
            .clickable { onClick() }
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {

            Box(
                Modifier
                    .size(52.dp)
                    .background(Color(0xFFF6F6F6), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(item.emoji, fontSize = 26.sp)
            }

            Spacer(Modifier.width(18.dp))

            Column(Modifier.weight(1f)) {
                Text(item.title, fontSize = 17.sp)
                Text(item.unit, fontSize = 14.sp, color = Color.Gray)
                Text(item.date, fontSize = 13.sp, color = Color.LightGray)
            }

            Box(
                Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(item.statusColor.copy(alpha = 0.18f))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(item.status, color = item.statusColor)
            }
        }
    }
}

// ================================================================
//                     MODAL DE RECIBO (SEM ALTERAÇÕES)
// ================================================================
@Composable
fun ReceiptModal(entry: HistoryEntry, onClose: () -> Unit) {
    val primary = Color(0xFF8B1538)

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .clickable { onClose() },
        contentAlignment = Alignment.Center
    ) {

        Column(
            Modifier
                .fillMaxWidth(0.88f)
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White)
        ) {

            Box(
                Modifier
                    .fillMaxWidth()
                    .background(primary)
                    .padding(vertical = 26.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Comprovante de Serviço", color = Color.White, fontSize = 20.sp)
            }

            Column(Modifier.padding(22.dp)) {

                ReceiptRow("Horário", "14:30")
                ReceiptRow("Máquina", entry.unit)
                ReceiptRow("Serviço", entry.title)
                ReceiptRow("Usuário", "Cliente Miracle")

                Spacer(Modifier.height(18.dp))

                Box(
                    Modifier
                        .fillMaxWidth()
                        .background(primary, RoundedCornerShape(12.dp))
                        .padding(18.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Valor Total", color = Color.White)
                        Text("R$ 12,00", color = Color.White, fontSize = 26.sp)
                    }
                }

                Spacer(Modifier.height(22.dp))

                Button(
                    onClick = { onClose() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(primary)
                ) {
                    Text("Fechar")
                }
            }
        }
    }
}

@Composable
fun ReceiptRow(label: String, value: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(label, color = Color.Gray, fontSize = 13.sp)
        Text(value, fontSize = 16.sp)
    }
}