package com.miracle.miraclelaundry.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.miracle.miraclelaundry.sharedui.login.MiracleLoginScreen
import com.miracle.miraclelaundry.ui.screens.HomeScreen
import com.miracle.miraclelaundry.ui.screens.MachinesScreen
import com.miracle.miraclelaundry.ui.screens.HistoryScreen
import com.miracle.miraclelaundry.ui.screens.WalletScreen
import com.miracle.miraclelaundry.ui.screens.ProfileScreen   // ⬅ ADICIONADO



object Routes {
    const val LOGIN = "login"
    const val HOME = "home"
    const val MACHINES = "machines"
    const val HISTORY = "history"
    const val WALLET = "wallet"
    const val PROFILE = "profile"   // ⬅ ADICIONADO
}

@Composable
fun NavGraph(navController: NavHostController) {

    NavHost(
        navController = navController,
        startDestination = Routes.LOGIN
    ) {

        // LOGIN
        composable(Routes.LOGIN) {
            MiracleLoginScreen(
                onLoginSuccess = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                }
            )
        }

        // HOME
        composable(Routes.HOME) {
            HomeScreen(navController)
        }

        // MÁQUINAS
        composable(Routes.MACHINES) {
            MachinesScreen(navController)
        }

        // HISTÓRICO
        composable(Routes.HISTORY) {
            HistoryScreen(navController)
        }

        // CARTEIRA
        composable(Routes.WALLET) {
            WalletScreen(navController)
        }

        // PERFIL  ⬅ ADICIONADO
        composable(Routes.PROFILE) {
            ProfileScreen(navController)
        }
    }
}