package com.miracle.miraclelaundry.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.miracle.miraclelaundry.navigation.Routes
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import com.miracle.miraclelaundry.R

// -------------------------------------------------
// TELA HOME
// -------------------------------------------------
@Composable
fun HomeScreen(navController: NavController) {

    val primary = Color(0xFF8B1538)
    val primaryDark = Color(0xFF6F0F2C)

    val headerBackground = Brush.verticalGradient(
        listOf(primaryDark, primary)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F5F5))
    ) {

        // ------------------------------
        // HEADER FIXO
        // ------------------------------
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(headerBackground)
                .padding(top = 64.dp, bottom = 20.dp)
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 18.dp)
            ) {

                // Logo + textos
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .shadow(8.dp, RoundedCornerShape(16.dp))
                            .background(Color.White, RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.miracle_logo),
                            contentDescription = "Logo Miracle Laundry",
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(16.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Text(
                            text = "Miracle Laundry",
                            fontSize = 26.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Text(
                            text = "Olá, Usuário Cliente! 👋",
                            fontSize = 15.sp,
                            color = Color(0xFFFFF8F8)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(22.dp))

                // Menu superior
                MenuBar(navController)
            }
        }

        // ------------------------------
        // CONTEÚDO SCROLLÁVEL
        // ------------------------------
        Column(
            modifier = Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {

            Spacer(modifier = Modifier.height(20.dp))

            WelcomeCard(primary)

            Spacer(modifier = Modifier.height(28.dp))

            Text(
                text = "Ações Rápidas",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // ----- Ações rápidas COM NAVEGAÇÃO CORRETA -----
            QuickActions(
                onNovaLavagem = { navController.navigate(Routes.MACHINES) },
                onAdicionarCartao = { navController.navigate(Routes.WALLET) },
                onVerHistorico = { navController.navigate(Routes.HISTORY) }
            )

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Atividade Recente",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937)
            )

            Spacer(modifier = Modifier.height(14.dp))

            RecentActivity()
        }
    }
}

// -------------------------------------------------
// MENU SUPERIOR – AGORA COM NAVEGAÇÃO
// -------------------------------------------------
@Composable
fun MenuBar(navController: NavController) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        MenuItem("🏠", "Início", selected = true) {
            navController.navigate(Routes.HOME)
        }

        MenuItem("🧺", "Máquinas", selected = false) {
            navController.navigate(Routes.MACHINES)
        }

        MenuItem("📜", "Histórico", selected = false) {
            navController.navigate(Routes.HISTORY)
        }

        MenuItem("💳", "Carteira", selected = false) {
            navController.navigate(Routes.WALLET)
        }

        MenuItem("👤", "Perfil", selected = false) {
            navController.navigate(Routes.PROFILE)
        }
    }
}

@Composable
fun MenuItem(
    emoji: String,
    text: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val bg = if (selected) {
        Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = 0.98f),
                Color(0xFFF4F4F4)
            )
        )
    } else {
        Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = 0.20f),
                Color.White.copy(alpha = 0.10f)
            )
        )
    }

    // Efeito de “apertar”
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.97f else 1f,
        animationSpec = tween(120),
        label = "menuItemScale"
    )

    Box(
        modifier = Modifier
            .size(width = 110.dp, height = 80.dp)
            .scale(scale)
            .clip(RoundedCornerShape(26.dp))
            .shadow(
                elevation = if (selected) 14.dp else 4.dp,
                shape = RoundedCornerShape(26.dp),
            )
            .background(bg)
            .clickable(
                interactionSource = interactionSource,
                indication = null
            ) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {

            Text(
                text = emoji,
                fontSize = 30.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = text,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = if (selected) Color(0xFF7A0F2D) else Color.White
            )
        }
    }
}

// -------------------------------------------------
// WELCOME CARD
// -------------------------------------------------
@Composable
fun WelcomeCard(primary: Color) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(16.dp, RoundedCornerShape(30.dp))
            .background(primary, RoundedCornerShape(30.dp))
            .padding(26.dp)
    ) {
        Column {
            Text(
                text = "Bem-vindo de volta! 👋",
                fontSize = 26.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Suas roupas sempre limpas e frescas.\nComece uma nova lavagem agora mesmo!",
                fontSize = 15.sp,
                color = Color(0xFFFFECEC)
            )
        }
    }
}

// -------------------------------------------------
// AÇÕES RÁPIDAS – AGORA COM OS BOTÕES CORRETOS
// -------------------------------------------------
@Composable
fun QuickActions(
    onNovaLavagem: () -> Unit,
    onAdicionarCartao: () -> Unit,
    onVerHistorico: () -> Unit
) {

    ActionCard(
        title = "Nova Lavagem",
        subtitle = "Iniciar ciclo agora",
        emoji = "🧺",
        color = Color(0xFF8B1538),
        onClick = onNovaLavagem
    )

    Spacer(Modifier.height(14.dp))

    ActionCard(
        title = "Adicionar Cartão",
        subtitle = "Cadastrar novo cartão",
        emoji = "💳",
        color = Color(0xFF0BA360),
        onClick = onAdicionarCartao
    )

    Spacer(Modifier.height(14.dp))

    ActionCard(
        title = "Ver Histórico",
        subtitle = "Últimas lavagens",
        emoji = "📜",
        color = Color(0xFF2563EB),
        onClick = onVerHistorico
    )
}

@Composable
fun ActionCard(
    title: String,
    subtitle: String,
    emoji: String,
    color: Color,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.97f else 1f,
        animationSpec = tween(120),
        label = "actionCardScale"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale)
            .shadow(16.dp, RoundedCornerShape(26.dp))
            .background(color, RoundedCornerShape(26.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null
            ) { onClick() }
            .padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {

            Text(emoji, fontSize = 36.sp)

            Spacer(modifier = Modifier.width(16.dp))

            Column {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    color = Color(0xFFECECEC),
                    fontSize = 14.sp
                )
            }
        }
    }
}

// -------------------------------------------------
// ATIVIDADE RECENTE
// -------------------------------------------------
@Composable
fun RecentActivity() {

    ActivityItem(
        emoji = "🧺",
        title = "Lavagem Completa",
        unit = "Unidade Centro - Máquina 03",
        status = "Concluído",
        statusColor = Color(0xFF34D399)
    )

    Spacer(Modifier.height(14.dp))

    ActivityItem(
        emoji = "💨",
        title = "Secagem Rápida",
        unit = "Unidade Norte - Secadora 01",
        status = "Concluído",
        statusColor = Color(0xFF60A5FA)
    )

    Spacer(Modifier.height(14.dp))

    ActivityItem(
        emoji = "💰",
        title = "Recarga de Créditos",
        unit = "R$ 50,00 adicionados",
        status = "Processado",
        statusColor = Color(0xFFA78BFA)
    )
}

@Composable
fun ActivityItem(
    emoji: String,
    title: String,
    unit: String,
    status: String,
    statusColor: Color
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(8.dp, RoundedCornerShape(26.dp))
            .background(Color.White, RoundedCornerShape(26.dp))
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {

            Box(
                modifier = Modifier
                    .size(52.dp)
                    .background(Color(0xFFF6F6F6), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(emoji, fontSize = 26.sp)
            }

            Spacer(modifier = Modifier.width(18.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(unit, fontSize = 14.sp, color = Color(0xFF6B7280))
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(statusColor.copy(alpha = 0.18f))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = status,
                    color = statusColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}