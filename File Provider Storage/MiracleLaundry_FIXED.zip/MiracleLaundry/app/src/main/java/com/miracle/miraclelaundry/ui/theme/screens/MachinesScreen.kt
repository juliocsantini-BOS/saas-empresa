package com.miracle.miraclelaundry.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.navigation.NavController
import com.miracle.miraclelaundry.navigation.Routes
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import com.miracle.miraclelaundry.R

// ========================================================================
// TELA PRINCIPAL - MACHINES SCREEN
// ========================================================================
@Composable
fun MachinesScreen(navController: NavController) {

    val primary = Color(0xFF8B1538)
    val primaryDark = Color(0xFF6F0F2C)

    val headerBackground = Brush.verticalGradient(
        listOf(primaryDark, primary)
    )

    var showUnitDialog by remember { mutableStateOf(false) }
    var selectedUnit by remember { mutableStateOf("Lavanderia Centro") }

    var selectedMachine by remember { mutableStateOf<MachineUi?>(null) }
    var showPaymentDialog by remember { mutableStateOf(false) }
    var selectedPaymentMethod by remember { mutableStateOf<PaymentMethod?>(null) }

    val machines = listOf(
        MachineUi("Lavadora 01", MachineType.WASHER, MachineStatus.USED, 15),
        MachineUi("Lavadora 02", MachineType.WASHER, MachineStatus.AVAILABLE, 0),
        MachineUi("Lavadora 03", MachineType.WASHER, MachineStatus.MAINTENANCE, 0),
        MachineUi("Secadora 01", MachineType.DRYER, MachineStatus.AVAILABLE, 0),
        MachineUi("Secadora 02", MachineType.DRYER, MachineStatus.USED, 7),
        MachineUi("Secadora 03", MachineType.DRYER, MachineStatus.AVAILABLE, 0)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F5F5))
    ) {

        // ---------------- HEADER ----------------
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(headerBackground)
                .padding(top = 64.dp, bottom = 22.dp)
        ) {

            Column(Modifier.padding(horizontal = 18.dp)) {

                Row(verticalAlignment = Alignment.CenterVertically) {

                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .shadow(8.dp, RoundedCornerShape(16.dp))
                            .background(Color.White, RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.miracle_logo),
                            contentDescription = "Logo Miracle Laundry",
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(16.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }

                    Spacer(Modifier.width(14.dp))

                    Column {
                        Text(
                            "Miracle Laundry",
                            fontSize = 26.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Text(
                            selectedUnit,
                            fontSize = 15.sp,
                            color = Color(0xFFFFF8F8)
                        )
                    }
                }

                Spacer(Modifier.height(22.dp))

                MachinesMenu(navController)
            }
        }

        // ---------------- CONTEÚDO ----------------
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {

            Spacer(Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {

                Text(
                    "Máquinas",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1F2937)
                )

                UnitButton(selectedUnit) {
                    showUnitDialog = true
                }
            }

            Spacer(Modifier.height(16.dp))

            machines.forEach { machine ->

                MachineCard(
                    machine = machine,
                    onStartClick = {
                        if (machine.status == MachineStatus.AVAILABLE) {
                            selectedMachine = machine
                            selectedPaymentMethod = null
                            showPaymentDialog = true
                        }
                    }
                )

                Spacer(Modifier.height(14.dp))
            }
        }
    }

    if (showPaymentDialog && selectedMachine != null) {
        PaymentDialog(
            machine = selectedMachine!!,
            selectedMethod = selectedPaymentMethod,
            onMethodSelected = { selectedPaymentMethod = it },
            onDismiss = { showPaymentDialog = false },
            onConfirm = { showPaymentDialog = false }
        )
    }

    if (showUnitDialog) {
        UnitSelectorDialog(
            selectedUnit = selectedUnit,
            onSelect = {
                selectedUnit = it
                showUnitDialog = false
            },
            onDismiss = { showUnitDialog = false }
        )
    }
}

// ========================================================================
// BOTÃO DE UNIDADE
// ========================================================================
@Composable
fun UnitButton(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .shadow(12.dp, RoundedCornerShape(30.dp))
            .clip(RoundedCornerShape(30.dp))
            .background(Color(0xFF8B1538))
            .clickable { onClick() }
            .padding(horizontal = 18.dp, vertical = 10.dp)
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

// ========================================================================
// MENU SUPERIOR
// ========================================================================
@Composable
fun MachinesMenu(navController: NavController) {
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        TopMenuItem("🏠", "Início", false) {
            navController.navigate(Routes.HOME)
        }
        TopMenuItem("🧺", "Máquinas", true) { }
        MenuItem("📜", "Histórico", selected = false) {
            navController.navigate(Routes.HISTORY)
        }
        TopMenuItem("💳", "Carteira", false) {
            navController.navigate(Routes.WALLET)
        }
        TopMenuItem("👤", "Perfil", false) {
            navController.navigate(Routes.PROFILE)
        }
    }
}

@Composable
fun TopMenuItem(
    emoji: String,
    text: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val bg = if (selected)
        Brush.verticalGradient(
            listOf(Color.White, Color(0xFFF4F4F4))
        )
    else
        Brush.verticalGradient(
            listOf(Color.White.copy(alpha = 0.20f), Color.White.copy(alpha = 0.10f))
        )

    Box(
        modifier = Modifier
            .size(110.dp, 80.dp)
            .clip(RoundedCornerShape(26.dp))
            .shadow(if (selected) 14.dp else 4.dp, RoundedCornerShape(26.dp))
            .background(bg)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 30.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                text,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = if (selected) Color(0xFF7A0F2D) else Color.White
            )
        }
    }
}

// ========================================================================
// CARD DE MÁQUINA
// ========================================================================
@Composable
fun MachineCard(machine: MachineUi, onStartClick: () -> Unit) {

    val color = if (machine.type == MachineType.WASHER) Color(0xFF8B1538) else Color(0xFF2563EB)

    val statusColor = when (machine.status) {
        MachineStatus.AVAILABLE -> Color(0xFF34D399)
        MachineStatus.USED -> Color(0xFF60A5FA)
        MachineStatus.MAINTENANCE -> Color(0xFFF97316)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(16.dp, RoundedCornerShape(26.dp))
            .background(color, RoundedCornerShape(26.dp))
            .padding(20.dp)
    ) {

        Column {

            Row(verticalAlignment = Alignment.CenterVertically) {

                Text(
                    text = if (machine.type == MachineType.WASHER) "🧺" else "🔥",
                    fontSize = 32.sp
                )

                Spacer(Modifier.width(12.dp))

                Column(Modifier.weight(1f)) {
                    Text(
                        text = machine.name,
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = when (machine.status) {
                            MachineStatus.AVAILABLE -> "Disponível"
                            MachineStatus.USED -> "Em uso • Faltam ${machine.remainingMinutes} min"
                            MachineStatus.MAINTENANCE -> "Em manutenção"
                        },
                        color = Color(0xFFFFE4E4),
                        fontSize = 14.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(statusColor.copy(alpha = 0.18f))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = when (machine.status) {
                            MachineStatus.AVAILABLE -> "Disponível"
                            MachineStatus.USED -> "Em uso"
                            MachineStatus.MAINTENANCE -> "Manutenção"
                        },
                        color = statusColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(Modifier.height(18.dp))

            Button(
                onClick = onStartClick,
                enabled = machine.status == MachineStatus.AVAILABLE,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = color,
                    disabledContainerColor = Color(0xFFE5E7EB),
                    disabledContentColor = Color(0xFF9CA3AF)
                )
            ) {
                Text(
                    text = if (machine.type == MachineType.WASHER) "Iniciar Lavagem" else "Iniciar Secagem",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }
    }
}

// ========================================================================
// MODAL DE UNIDADES
// ========================================================================
data class LaundryUnitUi(
    val name: String,
    val address: String,
    val distanceKm: Double
)

@Composable
fun UnitSelectorDialog(
    selectedUnit: String,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {

    val laundries = listOf(
        LaundryUnitUi("Lavanderia Centro", "Rua das Flores, 123 - Centro", 0.5),
        LaundryUnitUi("Clean Express", "Av. Principal, 456 - Jardins", 1.2),
        LaundryUnitUi("Lava Rápido Plus", "Rua do Comércio, 789 - Vila Nova", 2.1),
        LaundryUnitUi("Lavanderia Premium", "Av. Santos Dumont, 321 - Asa Sul", 2.8),
        LaundryUnitUi("Wash & Go", "Rua Sete de Setembro, 654 - Bela Vista", 3.5),
        LaundryUnitUi("Lavanderia Modelo", "Rua Augusta, 987 - Consolação", 4.2)
    )

    var search by remember { mutableStateOf("") }
    var sortByDistance by remember { mutableStateOf(false) }

    val filteredList = laundries
        .filter {
            it.name.contains(search, ignoreCase = true) ||
                    it.address.contains(search, ignoreCase = true)
        }
        .let { list ->
            if (sortByDistance) list.sortedBy { it.distanceKm } else list
        }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.55f))
            .clickable { onDismiss() },
        contentAlignment = Alignment.Center
    ) {

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .clickable(enabled = false) { },
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 20.dp)
        ) {

            Column {

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    Color(0xFF8B1538),
                                    Color(0xFF6B1130)
                                )
                            )
                        )
                        .padding(vertical = 28.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Escolha sua Lavanderia",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Column(
                    modifier = Modifier
                        .background(Color(0xFFF8F9FA))
                        .padding(18.dp)
                ) {

                    OutlinedTextField(
                        value = search,
                        onValueChange = { search = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        placeholder = {
                            Text("Buscar localização", fontSize = 14.sp)
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(Modifier.height(14.dp))

                    Button(
                        onClick = { sortByDistance = !sortByDistance },
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(10.dp, RoundedCornerShape(12.dp)),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF8B1538),
                            contentColor = Color.White
                        )
                    ) {
                        Text(
                            text = if (sortByDistance) "Ordenado por proximidade"
                            else "Lavanderias Próximas",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }

                Column(
                    modifier = Modifier
                        .heightIn(max = 380.dp)
                        .verticalScroll(rememberScrollState())
                        .padding(18.dp)
                ) {

                    filteredList.forEach { item ->

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                                .shadow(16.dp, RoundedCornerShape(18.dp))
                                .clip(RoundedCornerShape(18.dp))
                                .background(Color(0xFF8B1538))
                                .clickable { onSelect(item.name) }
                                .padding(16.dp)
                        ) {

                            Row(verticalAlignment = Alignment.CenterVertically) {

                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color.White.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("🧺", fontSize = 26.sp)
                                }

                                Spacer(Modifier.width(14.dp))

                                Column(Modifier.weight(1f)) {
                                    Text(
                                        text = item.name,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = item.address,
                                        fontSize = 14.sp,
                                        color = Color(0xFFFFEDEE)
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(20.dp))
                                            .background(Color.White.copy(alpha = 0.20f))
                                            .padding(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "%.1f km".format(item.distanceKm),
                                            color = Color.White,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 13.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    TextButton(onClick = onDismiss) {
                        Text(
                            text = "Fechar",
                            fontSize = 17.sp,
                            color = Color(0xFF8B1538),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// ========================================================================
// MODAL DE PAGAMENTO (ESTILO CANVA)
// ========================================================================
@Composable
fun PaymentDialog(
    machine: MachineUi,
    selectedMethod: PaymentMethod?,
    onMethodSelected: (PaymentMethod) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {

    val price = if (machine.type == MachineType.WASHER) 13.99 else 12.99
    val cycleTime = if (machine.type == MachineType.WASHER) "45 minutos" else "30 minutos"

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .clickable { onDismiss() },
        contentAlignment = Alignment.Center
    ) {

        Box(
            modifier = Modifier
                .padding(horizontal = 24.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .shadow(20.dp, RoundedCornerShape(22.dp))
                .background(Color.White)
                .clickable(enabled = false) { }
        ) {

            Column {

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF8B1538))
                        .padding(vertical = 20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Confirmação de Pagamento",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(
                    modifier = Modifier.padding(22.dp)
                ) {

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFFF5F5F5))
                            .padding(18.dp)
                    ) {

                        Column {

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Máquina:", color = Color.Gray, fontSize = 14.sp)
                                Text(machine.name, fontWeight = FontWeight.SemiBold)
                            }

                            Spacer(Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Tempo do ciclo:", color = Color.Gray, fontSize = 14.sp)
                                Text(cycleTime, fontWeight = FontWeight.SemiBold)
                            }

                            Spacer(Modifier.height(16.dp))

                            // CORREÇÃO DO ERRO AQUI
                            Divider(
                                color = Color(0xFFE0E0E0),
                                thickness = 1.dp
                            )

                            Spacer(Modifier.height(16.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Valor:", color = Color.Gray, fontSize = 14.sp)
                                Text(
                                    "R$ %.2f".format(price),
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF8B1538)
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(24.dp))

                    Text(
                        text = "Forma de Pagamento",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )

                    Spacer(Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {

                        PaymentOptionButton(
                            title = "PIX",
                            selected = selectedMethod == PaymentMethod.PIX,
                            modifier = Modifier.weight(1f)
                        ) { onMethodSelected(PaymentMethod.PIX) }

                        PaymentOptionButton(
                            title = "Crédito",
                            selected = selectedMethod == PaymentMethod.CREDIT,
                            modifier = Modifier.weight(1f)
                        ) { onMethodSelected(PaymentMethod.CREDIT) }

                        PaymentOptionButton(
                            title = "Débito",
                            selected = selectedMethod == PaymentMethod.DEBIT,
                            modifier = Modifier.weight(1f)
                        ) { onMethodSelected(PaymentMethod.DEBIT) }
                    }

                    Spacer(Modifier.height(26.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {

                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .weight(1f)
                                .height(54.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Cancelar")
                        }

                        Button(
                            onClick = onConfirm,
                            modifier = Modifier
                                .weight(1f)
                                .height(54.dp),
                            enabled = selectedMethod != null,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF8B1538),
                                contentColor = Color.White
                            )
                        ) {
                            Text(
                                "Finalizar Pagamento",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// ========================================================================
// BOTÃO DE OPÇÃO DE PAGAMENTO
// ========================================================================
@Composable
fun PaymentOptionButton(
    title: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val background = Color(0xFF8B1538)
    val textColor = Color.White

    Box(
        modifier = modifier
            .height(54.dp)
            .shadow(12.dp, RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(14.dp))
            .background(background)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            title,
            color = textColor,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

// ========================================================================
// MODELOS
// ========================================================================
enum class MachineType { WASHER, DRYER }
enum class MachineStatus { AVAILABLE, USED, MAINTENANCE }
enum class PaymentMethod { PIX, CREDIT, DEBIT }

data class MachineUi(
    val name: String,
    val type: MachineType,
    val status: MachineStatus,
    val remainingMinutes: Int
)