package com.miracle.miraclelaundry

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.navigation.compose.rememberNavController
import com.miracle.miraclelaundry.navigation.NavGraph
import com.miracle.miraclelaundry.ui.theme.MiracleLaundryTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MiracleLaundryTheme {
                val navController = rememberNavController()
                NavGraph(navController = navController)
            }
        }
    }
}
