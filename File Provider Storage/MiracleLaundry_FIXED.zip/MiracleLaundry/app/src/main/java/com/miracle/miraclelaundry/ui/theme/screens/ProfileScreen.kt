package com.miracle.miraclelaundry.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.miracle.miraclelaundry.navigation.Routes
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import com.miracle.miraclelaundry.R

// =====================================================================
// TELA PERFIL  — HEADER ATUALIZADO + layout intacto
// =====================================================================
@Composable
fun ProfileScreen(navController: NavController) {

    val primary = Color(0xFF8B1538)
    val primaryDark = Color(0xFF6F0F2C)

    var showPasswordModal by remember { mutableStateOf(false) }

    val headerBackground = Brush.verticalGradient(
        listOf(primaryDark, primary)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F5F5))
    ) {

        // ===========================================================
        // HEADER (AGORA IGUAL AO DA HOME)
        // ===========================================================
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(headerBackground)
                .padding(top = 64.dp, bottom = 26.dp)
        ) {
            Column(Modifier.padding(horizontal = 18.dp)) {

                // LOGO + TÍTULO + SUBTÍTULO
                Row(verticalAlignment = Alignment.CenterVertically) {

                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .shadow(8.dp, RoundedCornerShape(16.dp))
                            .background(Color.White, RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.miracle_logo),
                            contentDescription = "Logo Miracle Laundry",
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(16.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }

                    Spacer(Modifier.width(14.dp))

                    Column {
                        Text(
                            text = "Miracle Laundry",
                            fontSize = 26.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Text(
                            text = "Perfil do Usuário",
                            fontSize = 15.sp,
                            color = Color(0xFFFFF8F8)
                        )
                    }
                }

                Spacer(Modifier.height(22.dp))
                ProfileTopMenu(navController)
            }
        }

        // ===========================================================
        // CONTEÚDO
        // ===========================================================
        Column(
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState())
        ) {

            Spacer(Modifier.height(20.dp))

            PersonalInfoCard()

            Spacer(Modifier.height(18.dp))

            SecurityCard { showPasswordModal = true }

            Spacer(Modifier.height(18.dp))

            PreferencesCard()

            Spacer(Modifier.height(40.dp))
        }
    }

    if (showPasswordModal) {
        PasswordChangeModal(onClose = { showPasswordModal = false })
    }
}

// =====================================================================
// TOP MENU (sem alterações)
// =====================================================================
@Composable
fun ProfileTopMenu(navController: NavController) {

    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {

        TopMenuItem("🏠", "Início", false) { navController.navigate(Routes.HOME) }
        TopMenuItem("🧺", "Máquinas", false) { navController.navigate(Routes.MACHINES) }
        TopMenuItem("📜", "Histórico", false) { navController.navigate(Routes.HISTORY) }
        TopMenuItem("💳", "Carteira", false) { navController.navigate(Routes.WALLET) }
        TopMenuItem("👤", "Perfil", true) { }
    }
}

// =====================================================================
// CARD INFORMAÇÕES PESSOAIS
// =====================================================================
@Composable
fun PersonalInfoCard() {

    val primary = Color(0xFF8B1538)

    Box(
        modifier = Modifier
            .shadow(10.dp, RoundedCornerShape(22.dp))
            .background(Color.White, RoundedCornerShape(22.dp))
            .padding(20.dp)
    ) {

        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {

            // FOTO + NOME
            Row(verticalAlignment = Alignment.CenterVertically) {

                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFEEEEEE))
                        .clickable { /* abrir seletor de imagem */ },
                    contentAlignment = Alignment.Center
                ) {
                    Text("+", fontSize = 35.sp, color = primary, fontWeight = FontWeight.Bold)
                }

                Spacer(Modifier.width(16.dp))

                Column {
                    Text("Julio Santini", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Text("Cliente Premium", fontSize = 14.sp, color = primary)
                }
            }

            Divider(thickness = 1.dp, color = Color(0xFFE5E5E5))

            ProfileField("Nome Completo", "Julio Santini")
            ProfileField("Email", "juliocsantini@gmail.com")
            ProfileField("Data de Nascimento", "01/01/1995")
            ProfileField("Endereço", "São Paulo - SP")

            Button(
                onClick = { },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = primary)
            ) {
                Text("Salvar Alterações", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun ProfileField(label: String, value: String) {
    OutlinedTextField(
        value = value,
        onValueChange = {},
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp)
    )
}

// =====================================================================
// CARD SEGURANÇA
// =====================================================================
@Composable
fun SecurityCard(onClick: () -> Unit) {

    Box(
        modifier = Modifier
            .shadow(10.dp, RoundedCornerShape(22.dp))
            .background(Color.White, RoundedCornerShape(22.dp))
            .padding(20.dp)
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column {
            Text("Segurança", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
            Text("Alterar Senha", fontSize = 15.sp)
        }
    }
}

// =====================================================================
// CARD PREFERÊNCIAS
// =====================================================================
@Composable
fun PreferencesCard() {

    val primary = Color(0xFF8B1538)

    var email by remember { mutableStateOf(true) }
    var push by remember { mutableStateOf(false) }
    var offers by remember { mutableStateOf(true) }

    Box(
        modifier = Modifier
            .shadow(10.dp, RoundedCornerShape(22.dp))
            .background(Color.White, RoundedCornerShape(22.dp))
            .padding(20.dp)
    ) {

        Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {

            Text("Preferências", fontWeight = FontWeight.Bold, fontSize = 18.sp)

            PreferenceSwitch("Notificação por Email", email) { email = it }
            PreferenceSwitch("Notificação Push", push) { push = it }
            PreferenceSwitch("Ofertas e Promoções", offers) { offers = it }
        }
    }
}

@Composable
fun PreferenceSwitch(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {

    val primary = Color(0xFF8B1538)

    Row(verticalAlignment = Alignment.CenterVertically) {

        Text(title, modifier = Modifier.weight(1f))

        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = primary,
                checkedThumbColor = Color.White,
                uncheckedTrackColor = Color(0xFFE5E5E5),
                uncheckedThumbColor = Color(0xFF9CA3AF)
            )
        )
    }
}

// =====================================================================
// MODAL ALTERAR SENHA
// =====================================================================
@Composable
fun PasswordChangeModal(onClose: () -> Unit) {

    var current by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }

    val primary = Color(0xFF8B1538)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .clickable { onClose() },
        contentAlignment = Alignment.Center
    ) {

        Column(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White)
                .padding(20.dp)
        ) {

            Text("Alterar Senha", fontSize = 20.sp, fontWeight = FontWeight.Bold)

            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                value = current,
                onValueChange = { current = it },
                label = { Text("Senha Atual") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = newPass,
                onValueChange = { newPass = it },
                label = { Text("Nova Senha") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(Modifier.height(20.dp))

            Button(
                onClick = { onClose() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = primary)
            ) {
                Text("Salvar Nova Senha", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}