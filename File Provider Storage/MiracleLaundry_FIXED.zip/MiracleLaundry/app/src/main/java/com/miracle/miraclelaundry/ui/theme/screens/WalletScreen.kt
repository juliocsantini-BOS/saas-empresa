package com.miracle.miraclelaundry.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.navigation.NavController
import com.miracle.miraclelaundry.navigation.Routes
import kotlin.math.roundToInt
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import com.miracle.miraclelaundry.R

// ============================================================================
//  TELA CARTEIRA
// ============================================================================
@Composable
fun WalletScreen(navController: NavController) {

    val primary = Color(0xFF8B1538)
    val primaryDark = Color(0xFF6F0F2C)

    var showAddCardModal by remember { mutableStateOf(false) }

    val headerBackground = Brush.verticalGradient(
        listOf(primaryDark, primary)
    )

    // Cartões fictícios (em estado para permitir excluir)
    var cards by remember {
        mutableStateOf(
            listOf(
                WalletCardUi("Julio Santini", "•••• 1293", "07/28", Color(0xFF1E293B)),
                WalletCardUi("Maria Silva", "•••• 8821", "03/27", Color(0xFF065F46)),
                WalletCardUi("Conta Empresarial", "•••• 4410", "11/29", Color(0xFF6D28D9))
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F5F5))
    ) {

        // ---------------- HEADER IGUAL HOME (logo + Miracle + nome da tela) ----------------
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(headerBackground)
                .padding(top = 64.dp, bottom = 26.dp)
        ) {

            Column(
                modifier = Modifier.padding(horizontal = 18.dp)
            ) {

                // Logo + textos
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .shadow(8.dp, RoundedCornerShape(16.dp))
                            .background(Color.White, RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.miracle_logo),
                            contentDescription = "Logo Miracle Laundry",
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(16.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Text(
                            text = "Miracle Laundry",
                            fontSize = 26.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Text(
                            text = "Carteira",
                            fontSize = 15.sp,
                            color = Color(0xFFFFF8F8)
                        )
                    }
                }

                Spacer(Modifier.height(22.dp))
                WalletTopMenu(navController)
            }
        }

        // ---------------- LISTA DE CARTÕES ----------------
        Column(
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState())
        ) {

            Text(
                "Seus cartões",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                modifier = Modifier.padding(vertical = 12.dp)
            )

            cards.forEach { card ->
                SwipeableWalletCard(
                    card = card,
                    onDelete = { cards = cards.filter { it != card } }
                )
                Spacer(Modifier.height(14.dp))
            }

            Spacer(Modifier.height(20.dp))

            // Botão adicionar cartão
            AddCardButton { showAddCardModal = true }

            Spacer(Modifier.height(40.dp))
        }
    }

    if (showAddCardModal) {
        AddCardModal(onClose = { showAddCardModal = false })
    }
}

// ============================================================================
// SWIPE-TO-DELETE EM VOLTA DO CARD
// ============================================================================
@Composable
fun SwipeableWalletCard(
    card: WalletCardUi,
    onDelete: () -> Unit
) {
    var offsetX by remember { mutableStateOf(0f) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(170.dp)
    ) {
        // Fundo vermelho com X à direita
        Box(
            modifier = Modifier
                .matchParentSize()
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0xFFD32F2F)),
            contentAlignment = Alignment.CenterEnd
        ) {
            Text(
                text = "✕",
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .padding(end = 24.dp)
                    .clickable { onDelete() }
            )
        }

        // Card arrastável – usa exatamente o WalletCard original
        Box(
            modifier = Modifier
                .offset { IntOffset(offsetX.roundToInt(), 0) }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onHorizontalDrag = { _, dragAmount ->
                            val newOffset = offsetX + dragAmount
                            offsetX = newOffset.coerceIn(-300f, 0f)
                        },
                        onDragEnd = {
                            if (offsetX < -120f) {
                                onDelete()
                            }
                            offsetX = 0f
                        }
                    )
                }
        ) {
            WalletCard(card)
        }
    }
}

// ============================================================================
// TOP MENU
// ============================================================================
@Composable
fun WalletTopMenu(navController: NavController) {
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {

        TopMenuItem("🏠", "Início", false) {
            navController.navigate(Routes.HOME)
        }
        TopMenuItem("🧺", "Máquinas", false) {
            navController.navigate(Routes.MACHINES)
        }
        TopMenuItem("📜", "Histórico", false) {
            navController.navigate(Routes.HISTORY)
        }
        TopMenuItem("💳", "Carteira", true) { }
        TopMenuItem("👤", "Perfil", false) {
            navController.navigate(Routes.PROFILE)
        }
    }
}

// ============================================================================
// CARTÃO VISUAL
// ============================================================================
data class WalletCardUi(
    val name: String,
    val number: String,
    val expiry: String,
    val color: Color
)

@Composable
fun WalletCard(card: WalletCardUi) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(170.dp)
            .shadow(10.dp, RoundedCornerShape(22.dp))
            .background(card.color, RoundedCornerShape(22.dp))
            .padding(22.dp)
    ) {

        Column(Modifier.fillMaxSize()) {

            Text(
                text = "VISA",
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.weight(1f))

            Text(
                text = card.number,
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.height(8.dp))

            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {

                Column {
                    Text("Nome", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                    Text(card.name, color = Color.White, fontWeight = FontWeight.Bold)
                }

                Column {
                    Text("Validade", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                    Text(card.expiry, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ============================================================================
// BOTÃO "Adicionar Cartão"
// ============================================================================
@Composable
fun AddCardButton(onClick: () -> Unit) {

    val primary = Color(0xFF8B1538)

    Button(
        onClick = { onClick() },
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = primary,
            contentColor = Color.White
        )
    ) {
        Text(
            "+ Adicionar novo cartão",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

// ============================================================================
// MODAL — ADICIONAR CARTÃO
// ============================================================================
@Composable
fun AddCardModal(onClose: () -> Unit) {

    var name by remember { mutableStateOf("") }
    var number by remember { mutableStateOf("") }
    var expiry by remember { mutableStateOf("") }
    var cvv by remember { mutableStateOf("") }

    val primary = Color(0xFF8B1538)

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .clickable { onClose() },
        contentAlignment = Alignment.Center
    ) {

        Column(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .clip(RoundedCornerShape(22.dp))
                .background(Color.White)
        ) {

            // HEADER
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(primary, primary.copy(alpha = 0.9f))
                        )
                    )
                    .padding(20.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Column {
                    Text(
                        "Adicionar Novo Cartão",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Insira os dados do seu cartão",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 14.sp
                    )
                }
            }

            Column(Modifier.padding(22.dp)) {

                // PREVIEW
                CardPreview(number, name, expiry)

                Spacer(Modifier.height(16.dp))

                // FORM
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nome do titular") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(Modifier.height(12.dp))

                OutlinedTextField(
                    value = number,
                    onValueChange = {
                        if (it.length <= 19) number = it.replace(" ", "").chunked(4).joinToString(" ")
                    },
                    label = { Text("Número do cartão") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {

                    OutlinedTextField(
                        value = expiry,
                        onValueChange = {
                            val digits = it.filter { ch -> ch.isDigit() }
                            expiry = when {
                                digits.length <= 2 -> digits
                                digits.length <= 4 -> digits.substring(0, 2) + "/" + digits.substring(2)
                                else -> expiry
                            }
                        },
                        label = { Text("Validade (MM/AA)") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = cvv,
                        onValueChange = { if (it.length <= 4) cvv = it.filter(Char::isDigit) },
                        label = { Text("CVV") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                Spacer(Modifier.height(22.dp))

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    OutlinedButton(
                        onClick = { onClose() },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("Cancelar")
                    }

                    Button(
                        onClick = { onClose() },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = primary,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("Adicionar Cartão")
                    }
                }
            }
        }
    }
}

// ============================================================================
// PREVIEW DO CARTÃO
// ============================================================================
@Composable
fun CardPreview(number: String, name: String, expiry: String) {

    val primary = Color(0xFF8B1538)

    Box(
        Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    listOf(primary, primary.copy(alpha = 0.8f))
                ),
                RoundedCornerShape(20.dp)
            )
            .padding(22.dp)
    ) {

        Column {

            Box(
                Modifier
                    .size(width = 60.dp, height = 40.dp)
                    .background(Color(0xFFFFD700), RoundedCornerShape(8.dp))
            )

            Spacer(Modifier.height(12.dp))

            Text(
                text = if (number.isBlank()) "•••• •••• •••• ••••" else number,
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.height(12.dp))

            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {

                Column {
                    Text("Nome do titular", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                    Text(
                        if (name.isBlank()) "SEU NOME AQUI" else name.uppercase(),
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column {
                    Text("Validade", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                    Text(
                        if (expiry.isBlank()) "MM/AA" else expiry,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}