package com.miracle.miraclelaundry.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.miracle.miraclelaundry.R

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun MiracleLoginScreen(
    onLoginSuccess: () -> Unit,
    showAdminAccess: Boolean = true
) {

    var selectedTab by remember { mutableStateOf(AuthTab.ENTRAR) }
    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showAdminModal by remember { mutableStateOf(false) }

    // Segurança extra: se este login estiver em modo kiosk (sem admin), garante que o modal não abre
    LaunchedEffect(showAdminAccess) {
        if (!showAdminAccess) showAdminModal = false
    }

    val primary = Color(0xFF8B1538)
    val primaryDark = Color(0xFF6F0F2C)

    val backgroundGradient = Brush.verticalGradient(
        listOf(primaryDark, primary)
    )

    val blurRadius by animateDpAsState(
        targetValue = if (showAdminModal) 18.dp else 0.dp,
        animationSpec = tween(200),
        label = "backgroundBlur"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundGradient)
    ) {

        Box(
            modifier = Modifier
                .matchParentSize()
                .blur(blurRadius)
        ) {

            // ILUMINAÇÃO DE FUNDO
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .offset(x = (-60).dp, y = 80.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(Color(0x22FFFFFF), Color.Transparent)
                        )
                    )
            )

            Box(
                modifier = Modifier
                    .size(260.dp)
                    .offset(x = 60.dp, y = 520.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(Color(0x22FFFFFF), Color.Transparent)
                        )
                    )
            )

            // CARD
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .align(Alignment.Center)
            ) {

                val cardScale = remember { Animatable(0.9f) }
                LaunchedEffect(Unit) {
                    cardScale.animateTo(
                        1f,
                        animationSpec = spring(
                            stiffness = Spring.StiffnessMediumLow,
                            dampingRatio = Spring.DampingRatioMediumBouncy
                        )
                    )
                }

                Column(
                    modifier = Modifier
                        .scale(cardScale.value)
                        .fillMaxWidth()
                        .shadow(24.dp, RoundedCornerShape(32.dp))
                        .background(Color.White, RoundedCornerShape(32.dp))
                        .padding(horizontal = 28.dp, vertical = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    // QUADRADO DO LOGO – FUNDO BRANCO
                    Box(
                        modifier = Modifier
                            .offset(y = (-18).dp)
                            .size(80.dp)
                            .shadow(18.dp, RoundedCornerShape(24.dp))
                            .background(Color.White, RoundedCornerShape(24.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.miracle_logo),
                            contentDescription = "Logo Miracle Laundry",
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(24.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }

                    Text(
                        text = "Miracle Laundry",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = primary
                    )

                    Text(
                        text = "Bem-vindo ao futuro da lavanderia",
                        color = Color(0xFF6B7280),
                        fontSize = 14.sp,
                        modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .background(Color(0xFFF3F4F6), RoundedCornerShape(999.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {

                        AuthTabButton(
                            text = "Entrar",
                            icon = "🔐",
                            selected = selectedTab == AuthTab.ENTRAR,
                            primary = primary,
                            primaryDark = primaryDark,
                            modifier = Modifier.weight(1f)
                        ) { selectedTab = AuthTab.ENTRAR }

                        AuthTabButton(
                            text = "Cadastrar",
                            icon = "✨",
                            selected = selectedTab == AuthTab.CADASTRAR,
                            primary = primary,
                            primaryDark = primaryDark,
                            modifier = Modifier.weight(1f)
                        ) { selectedTab = AuthTab.CADASTRAR }
                    }

                    Spacer(Modifier.height(24.dp))

                    AnimatedContent(
                        targetState = selectedTab,
                        transitionSpec = {
                            fadeIn(tween(250)) +
                                    slideInVertically(
                                        tween(250),
                                        initialOffsetY = { it / 4 }
                                    ) togetherWith
                                    fadeOut(tween(200)) +
                                    slideOutVertically(
                                        tween(200),
                                        targetOffsetY = { it / 4 }
                                    )
                        },
                        label = "formAnimation"
                    ) { tab ->

                        Column {

                            if (tab == AuthTab.CADASTRAR) {
                                FormField(
                                    label = "👤 Nome Completo",
                                    value = fullName,
                                    placeholder = "Digite seu nome completo",
                                    onChange = { fullName = it }
                                )
                                Spacer(Modifier.height(16.dp))
                            }

                            FormField(
                                label = "📧 Email",
                                value = email,
                                placeholder = "seu@email.com",
                                onChange = { email = it }
                            )

                            Spacer(Modifier.height(16.dp))

                            FormField(
                                label = "🔒 Senha",
                                value = password,
                                placeholder = "Mínimo 6 caracteres",
                                onChange = { password = it }
                            )
                        }
                    }

                    Spacer(Modifier.height(24.dp))

                    val mainButtonText = when (selectedTab) {
                        AuthTab.ENTRAR -> "🚀  Entrar Agora"
                        AuthTab.CADASTRAR -> "🎉  Criar Conta"
                    }

                    PremiumShimmerButton(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        backgroundColor = primary,
                        onClick = { onLoginSuccess() }
                    ) {
                        Text(
                            text = mainButtonText,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    }

                    // Separador + Admin (somente quando showAdminAccess = true)
                    if (showAdminAccess) {
                        Spacer(Modifier.height(24.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Divider(modifier = Modifier.weight(1f))
                            Text(
                                text = "  ou  ",
                                fontSize = 12.sp,
                                color = Color(0xFF9CA3AF)
                            )
                            Divider(modifier = Modifier.weight(1f))
                        }

                        Spacer(Modifier.height(16.dp))

                        PremiumShimmerButton(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp),
                            backgroundColor = primaryDark,
                            onClick = { showAdminModal = true }
                        ) {
                            Text(
                                text = "🔐  Acesso Administrativo",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }

        if (showAdminAccess && showAdminModal) {
            AdminLoginDialog(
                onDismiss = { showAdminModal = false },
                onLogin = { _, _ -> showAdminModal = false }
            )
        }
    }
}

// ------------------------------------------------------
// CAMPOS / COMPONENTES / MODAL
// ------------------------------------------------------

private enum class AuthTab {
    ENTRAR, CADASTRAR
}

@Composable
fun FormField(
    label: String,
    value: String,
    placeholder: String,
    onChange: (String) -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF4B5563)
        )
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onChange,
            placeholder = { Text(placeholder) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun AuthTabButton(
    text: String,
    icon: String,
    selected: Boolean,
    primary: Color,
    primaryDark: Color,
    modifier: Modifier,
    onClick: () -> Unit
) {

    val background =
        if (selected) Brush.verticalGradient(listOf(primary, primaryDark))
        else Brush.linearGradient(listOf(Color(0xFFF9FAFB), Color(0xFFF3F4F6)))

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(999.dp))
            .background(background)
            .shadow(if (selected) 8.dp else 2.dp, RoundedCornerShape(999.dp))
            .clickable { onClick() }
            .height(44.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = icon, fontSize = 14.sp, modifier = Modifier.padding(end = 6.dp))
            Text(
                text = text,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = if (selected) Color.White else Color(0xFF6B7280)
            )
        }
    }
}

@Composable
fun PremiumShimmerButton(
    modifier: Modifier = Modifier,
    backgroundColor: Color,
    onClick: () -> Unit,
    content: @Composable RowScope.() -> Unit
) {
    val shimmerColors = listOf(
        backgroundColor.copy(alpha = 0.96f),
        backgroundColor.copy(alpha = 1.0f),
        backgroundColor.copy(alpha = 0.96f)
    )

    val infiniteTransition = rememberInfiniteTransition(label = "shimmerSoft")

    val offsetX by infiniteTransition.animateFloat(
        initialValue = -120f,
        targetValue = 120f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 2600,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "offsetAnimSoft"
    )

    val brush = Brush.linearGradient(
        colors = shimmerColors,
        start = Offset(offsetX - 80f, 0f),
        end = Offset(offsetX + 80f, 0f)
    )

    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.98f else 1f,
        animationSpec = tween(120),
        label = "scaleAnimSoft"
    )

    Button(
        onClick = onClick,
        modifier = modifier.scale(scale),
        interactionSource = interactionSource,
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
        contentPadding = PaddingValues(0.dp)
    ) {
        Box(
            modifier = Modifier
                .background(brush, RoundedCornerShape(18.dp))
                .fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Row(content = content)
        }
    }
}

@Composable
private fun AdminLoginDialog(
    onDismiss: () -> Unit,
    onLogin: (String, String) -> Unit
) {
    var adminUser by remember { mutableStateOf("") }
    var adminPassword by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f)),
        contentAlignment = Alignment.Center
    ) {

        Column(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .shadow(30.dp, RoundedCornerShape(28.dp))
                .background(Color.White, RoundedCornerShape(28.dp))
                .padding(horizontal = 28.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Text(
                text = "Login Administrativo",
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF111827),
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(16.dp))

            FormField(
                label = "Usuário",
                value = adminUser,
                placeholder = "Digite o usuário",
                onChange = { adminUser = it }
            )

            Spacer(Modifier.height(16.dp))

            FormField(
                label = "Senha",
                value = adminPassword,
                placeholder = "Digite a senha",
                onChange = { adminPassword = it }
            )

            Spacer(Modifier.height(28.dp))

            Button(
                onClick = { onLogin(adminUser, adminPassword) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF8B1538)
                )
            ) {
                Text(
                    text = "Entrar",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 16.sp
                )
            }

            Spacer(Modifier.height(12.dp))

            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(18.dp)
            ) {
                Text(
                    text = "Cancelar",
                    fontWeight = FontWeight.Medium,
                    fontSize = 15.sp,
                    color = Color(0xFF6B7280)
                )
            }
        }
    }
}
