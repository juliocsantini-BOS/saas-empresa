plugins {
    id("com.android.application") version "8.3.1" apply false
    id("com.android.library") version "8.3.1" apply false

    // Kotlin 1.9.x + Compose "clássico" (composeOptions) = menos dor de cabeça.
    // (Evita o erro: "Starting in Kotlin 2.0, the Compose Compiler Gradle plugin is required")
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false

    id("com.google.gms.google-services") version "4.4.2" apply false
}