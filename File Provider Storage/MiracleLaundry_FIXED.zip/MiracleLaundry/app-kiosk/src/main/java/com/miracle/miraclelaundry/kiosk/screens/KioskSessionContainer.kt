package com.miracle.miraclelaundry.kiosk.screens

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import kotlinx.coroutines.delay

/**
 * Container de sessão do Kiosk:
 * - reinicia o timer em qualquer toque na tela
 * - se ficar inativo, chama onTimeout()
 */
@Composable
fun KioskSessionContainer(
    timeoutMs: Long = 60_000L, // 60s (depois você me fala se quer 30s, 2min, 5min)
    onTimeout: () -> Unit,
    content: @Composable () -> Unit
) {
    var lastTouch by remember { mutableStateOf(System.currentTimeMillis()) }

    LaunchedEffect(lastTouch, timeoutMs) {
        while (true) {
            val now = System.currentTimeMillis()
            val elapsed = now - lastTouch
            val remaining = timeoutMs - elapsed

            if (remaining <= 0) {
                onTimeout()
                // evita disparar mil vezes seguidas
                lastTouch = System.currentTimeMillis()
                break
            } else {
                delay(minOf(remaining, 1_000L))
            }
        }
    }

    Box(
        modifier = Modifier.pointerInput(Unit) {
            detectTapGestures(
                onTap = { lastTouch = System.currentTimeMillis() },
                onPress = {
                    lastTouch = System.currentTimeMillis()
                    tryAwaitRelease()
                }
            )
        }
    ) {
        content()
    }
}
