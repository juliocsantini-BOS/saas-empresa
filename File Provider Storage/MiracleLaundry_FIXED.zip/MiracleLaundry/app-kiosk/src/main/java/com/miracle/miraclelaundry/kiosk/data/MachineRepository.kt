package com.miracle.miraclelaundry.kiosk.data

import com.google.firebase.firestore.FirebaseFirestore
import com.miracle.miraclelaundry.kiosk.model.Machine
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class MachineRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val collectionName: String = "maquinas"
) {
    fun observeMachines(): Flow<List<Machine>> = callbackFlow {
        val reg = db.collection(collectionName)
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }

                val list = snap?.documents?.map { doc ->
                    val name = doc.getString("name") ?: ""
                    val type = doc.getString("type") ?: "WASHER"
                    val status = doc.getString("status") ?: "IDLE"

                    val priceCents: Long =
                        doc.getLong("priceCents")
                            ?: (doc.get("priceCents") as? Number)?.toLong()
                            ?: 0L

                    Machine(
                        id = doc.id,
                        name = name,
                        type = type,
                        priceCents = priceCents,
                        status = status
                    )
                } ?: emptyList()

                trySend(list)
            }

        awaitClose { reg.remove() }
    }
}