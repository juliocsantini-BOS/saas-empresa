package com.miracle.miraclelaundry.kiosk.model

data class Machine(
    val id: String = "",
    val name: String = "",
    val type: String = "WASHER",
    val priceCents: Long = 0,
    val status: String = "IDLE"
)