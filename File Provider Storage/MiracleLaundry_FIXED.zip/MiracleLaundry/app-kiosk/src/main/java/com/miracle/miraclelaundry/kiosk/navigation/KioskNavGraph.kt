package com.miracle.miraclelaundry.kiosk.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.miracle.miraclelaundry.kiosk.screens.MachineSelectScreen
import com.miracle.miraclelaundry.sharedui.login.MiracleLoginScreen

object KioskRoutes {
    const val LOGIN = "login"
    const val MACHINES = "machines"
}

@Composable
fun KioskNavGraph(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = KioskRoutes.LOGIN
    ) {
        composable(KioskRoutes.LOGIN) {
            MiracleLoginScreen(
                title = "Kiosk Login",
                onLoginSuccess = {
                    navController.navigate(KioskRoutes.MACHINES) {
                        popUpTo(KioskRoutes.LOGIN) { inclusive = true }
                    }
                }
            )
        }

        composable(KioskRoutes.MACHINES) {
            MachineSelectScreen(
                onBack = { /* kiosk: sem voltar */ }
            )
        }
    }
}