package com.miracle.miraclelaundry.kiosk.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.miracle.miraclelaundry.kiosk.data.MachineRepository
import com.miracle.miraclelaundry.kiosk.model.Machine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MachinesViewModel : ViewModel() {

    private val repo = MachineRepository()

    private val _machines = MutableStateFlow<List<Machine>>(emptyList())
    val machines: StateFlow<List<Machine>> = _machines.asStateFlow()

    init {
        viewModelScope.launch {
            repo.observeMachines().collect { list ->
                _machines.value = list
            }
        }
    }
}