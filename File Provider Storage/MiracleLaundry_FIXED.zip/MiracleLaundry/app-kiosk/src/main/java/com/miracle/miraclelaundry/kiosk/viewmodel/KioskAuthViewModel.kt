package com.miracle.miraclelaundry.kiosk.viewmodel

import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class KioskAuthViewModel : ViewModel() {

    private val auth = FirebaseAuth.getInstance()

    private val _isLoggedIn = MutableStateFlow(auth.currentUser != null)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    fun refreshAuthState() {
        _isLoggedIn.value = auth.currentUser != null
        _message.value = null
        _loading.value = false
    }

    fun login(email: String, password: String) {
        _loading.value = true
        _message.value = null

        auth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                _loading.value = false
                _isLoggedIn.value = true
            }
            .addOnFailureListener { e ->
                _loading.value = false
                _isLoggedIn.value = false
                _message.value = e.message ?: "Falha ao entrar."
            }
    }

    fun register(email: String, password: String) {
        _loading.value = true
        _message.value = null

        auth.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                _loading.value = false
                _isLoggedIn.value = true
            }
            .addOnFailureListener { e ->
                _loading.value = false
                _isLoggedIn.value = false
                _message.value = e.message ?: "Falha ao cadastrar."
            }
    }
}