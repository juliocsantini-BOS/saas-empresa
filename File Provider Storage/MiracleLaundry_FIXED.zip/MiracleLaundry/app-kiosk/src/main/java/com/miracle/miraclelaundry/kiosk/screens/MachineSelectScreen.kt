package com.miracle.miraclelaundry.kiosk.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

data class MachineUi(
    val id: String,
    val name: String,
    val type: String,
    val priceCents: Long,
    val status: String
)

@Composable
fun MachineSelectScreen(
    onBack: () -> Unit
) {
    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()

    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var machines by remember { mutableStateOf<List<MachineUi>>(emptyList()) }

    LaunchedEffect(Unit) {
        loading = true
        error = null

        if (auth.currentUser == null) {
            loading = false
            error = "Kiosk ainda não autenticou no Firebase."
            machines = emptyList()
            return@LaunchedEffect
        }

        try {
            val snap = db.collection("maquinas").get().await()
            machines = snap.documents.map { doc ->
                MachineUi(
                    id = doc.id,
                    name = doc.getString("name") ?: doc.getString("nome") ?: "Sem nome",
                    type = doc.getString("type") ?: "UNKNOWN",
                    priceCents = (doc.getLong("priceCents") ?: 0L),
                    status = doc.getString("status") ?: "IDLE"
                )
            }
            loading = false
        } catch (e: Exception) {
            loading = false
            error = e.message ?: "Erro ao carregar máquinas"
            machines = emptyList()
        }
    }

    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Escolha uma máquina", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))

        if (error != null) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                Text(
                    modifier = Modifier.padding(12.dp),
                    text = error!!,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            }
            Spacer(Modifier.height(12.dp))
        }

        if (loading) {
            CircularProgressIndicator()
            Spacer(Modifier.height(12.dp))
            Text("Carregando...")
            return@Column
        }

        if (machines.isEmpty()) {
            Text("Nenhuma máquina cadastrada no Firestore.")
            return@Column
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(machines) { m ->
                Card {
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Text(m.name, style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(6.dp))
                        Text("Tipo: ${m.type} • Status: ${m.status}")
                        Text("Preço: R$ ${(m.priceCents / 100.0)}")
                    }
                }
            }
        }
    }
}